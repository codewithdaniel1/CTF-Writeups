Recovered relay artifact TX-7.

Diagnostics indicate the final transmission was queued but withheld locally.
The relay was not broken. It chose restraint.

Artifacts in this bundle may describe the last stable path inward.
Analyze what remains.
